from flask import Flask, render_template, request
from pymongo import MongoClient

app = Flask(__name__)


client = MongoClient('mongodb://localhost:27017/')
db = client['invoices']
collection = db['shop']

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        shop_name = request.form['shopName']
        shop_address = request.form['shopAddress']
        gst_number = request.form['gstNumber']

        new_data = {
            'shopName': shop_name,
            'shopAddress': shop_address,
            'gstNumber': gst_number
        }
        
        collection.insert_one(new_data)
        
        return 'Data submitted successfully!'
    return render_template('shop_reg.html')

if __name__ == '__main__':
    app.run(debug=True)
