from pymongo import MongoClient
from datetime import datetime

client = MongoClient('mongodb://localhost:27017/')


db = client['invoices']


collection = db['invoices']

data = {
    
    "date": datetime.now(),
    "invoice_details": {
        "invoice_number": "DEL5-5278371",
        "order_date": "18.12.2023",
        "invoice_details": "HR-DEL5-1014-2324",
        "invoice_date": "19.12.2023"
    },
    "seller_details": {
        "seller_address": "[*Rect/Killa Nos. 38//8/2 min, 192//22/1,196//2/1/1]",
        "gst_number": "[06AAPCA6346P1ZZ ]",
        "shipped_from_address": "[Village Binola, National Highway -8]"
    },
    "billing_address": "[pakshi vihar campus]",
    "shipping_address": "[pakshi vihar campus]",
    "items": [
        {
            "serial_number": 1,
            "item": "name1",
            "quantity": 2,
            "price": 10.00,
            "total_amount": 20.00
        },
        {
            "serial_number": 2,
            "item": "name2",
            "quantity": 1,
            "price": 15.00,
            "total_amount": 15.00
        }
    ]
}


collection.insert_one(data)
