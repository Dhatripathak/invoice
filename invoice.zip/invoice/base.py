from flask import Flask, jsonify
from pymongo import MongoClient

app = Flask(__name__)

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
db = client['your_database_name']  # Replace 'your_database_name' with your actual database name
collection = db['your_collection_name']  # Replace 'your_collection_name' with your actual collection name

# Define routes
@app.route('/invoice', methods=['GET'])
def get_invoice():
    # Fetch data from MongoDB
    invoice_data = collection.find_one()
    # Return the data as JSON
    return jsonify(invoice_data)

if __name__ == '__main__':
    app.run(debug=True)
