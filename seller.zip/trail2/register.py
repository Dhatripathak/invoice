from flask import Flask, render_template, request
from pymongo import MongoClient

app = Flask(__name__)


client = MongoClient('mongodb://localhost:27017/')
db = client['shop_database']
collection = db['shops']

@app.route('/')
def index():
    return render_template('register.html')

@app.route('/submit', methods=['POST'])
def submit():
    if request.method == 'POST':
        shop_name = request.form['shopName']
        shop_address = request.form['shopAddress']
        gst_number = request.form['gstNumber']
        
        # Print/log the form data
        print("Form Data Received:")
        print("Shop Name:", shop_name)
        print("Shop Address:", shop_address)
        print("GST Number:", gst_number)
        
        # Insert data into MongoDB
        shop_data = {
            'shop_name': shop_name,
            'shop_address': shop_address,
            'gst_number': gst_number
        }
        collection.insert_one(shop_data)
        
        return 'Data submitted successfully!'
    else:
        return 'Error in form submission'


if __name__ == '__main__':
    app.run(debug=True)
