from flask import Flask, render_template, request, redirect, url_for
from pymongo import MongoClient
from datetime import datetime

app = Flask(__name__)

# MongoDB connection
client = MongoClient('mongodb+srv://hashmap:gbqwF77TFjZu54pa@invoices.cfa4zkk.mongodb.net/?retryWrites=true&w=majority')
db = client['shop_data']
shops_collection = db['shops']
items_collection = db['items']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/seller', methods=['GET', 'POST'])
def seller():
    if request.method == 'POST':
        shop_no = request.form['shop_no']
        shop = shops_collection.find_one({'registration_no': shop_no})
        if shop:
            return redirect(url_for('shop_entry', shop_no=shop_no))
        else:
            return render_template('shop_reg.html', shop_no=shop_no)
    return render_template('seller.html')

@app.route('/shop_entry/<shop_no>', methods=['GET', 'POST'])
def shop_entry(shop_no):
    if request.method == 'POST':
        item_name = request.form['item_name']
        item_quantity = int(request.form['item_quantity'])
        item_price = float(request.form['item_price'])
        gst_percentage = float(request.form['gst_percentage'])
        
        # Save item data to MongoDB
        items_collection.insert_one({
            'shop_no': shop_no,
            'item_name': item_name,
            'item_quantity': item_quantity,
            'item_price': item_price,
            'gst_percentage': gst_percentage
        })
        
        return redirect(url_for('index'))
    
    return render_template('shop_entry.html', shop_no=shop_no)

@app.route('/register_shop', methods=['POST'])
def register_shop():
    if request.method == 'POST':
        shop_name = request.form['shopName']
        billing_address = request.form['billingAddress']
        shipping_address = request.form['shippingAddress']
        gst_number = request.form['gstNumber']
        
        # Check if the shop already exists
        existing_shop = shops_collection.find_one({'gst_number': gst_number})
        if existing_shop:
            return "Shop with this GST number already exists."
        
        # Save shop data to MongoDB
        shops_collection.insert_one({
            'name': shop_name,
            'billing_address': billing_address,
            'shipping_address': shipping_address,
            'registration_no': gst_number
        })
        
        return render_template('thank_you.html')


@app.route('/customer')
def customer():
    shop_list = shops_collection.find()
    return render_template('customer.html', shop_list=shop_list)

@app.route('/shop/<shop_no>')
def shop(shop_no):
    shop = shops_collection.find_one({'registration_no': shop_no})
    print(shop)
    if shop:
        items = items_collection.find({'shop_no': shop_no})
        print("items", items)
        if items:
            return render_template('shop.html', shop=shop, items=items)
        else:
            return "No items found for this shop."
    else:
        return "Shop not found."


@app.route('/push_invoice')
def push_invoice():

    # Tax details
    tax_type = "GST"
    tax_rate = 0.18  # 18%

    # Form data to be inserted into MongoDB
    data = {
        "date": datetime.now(),
        "invoice_details": {
            "invoice_number": "DEL5-5278371",
            "order_date": "18.12.2023",
            "invoice_details": "HR-DEL5-1014-2324",
            "invoice_date": "19.12.2023"
        },
        "seller_details": {
            "seller_address": "[*Rect/Killa Nos. 38//8/2 min, 192//22/1,196//2/1/1]",
            "gst_number": "[06AAPCA6346P1ZZ ]",
            "shipped_from_address": "[Village Binola, National Highway -8]"
        },
        "billing_address": "[pakshi vihar campus]",
        "shipping_address": "[pakshi vihar campus]",
        "materials": [
            {
                "serial_number": 1,
                "material": "name1",
                "quantity": 2,
                "price": 10.00,
                "tax_type": tax_type,
                "tax_rate": tax_rate,
                "tax_amount": round(2 * 10.00 * tax_rate, 2),
                "total_amount": round((2 * 10.00) + (2 * 10.00 * tax_rate), 2)
            },
            {
                "serial_number": 2,
                "material": "name2",
                "quantity": 1,
                "price": 15.00,
                "tax_type": tax_type,
                "tax_rate": tax_rate,
                "tax_amount": round(1 * 15.00 * tax_rate, 2),
                "total_amount": round((1 * 15.00) + (1 * 15.00 * tax_rate), 2)
            }
        ],
    }

    collection.insert_one(data)

    return "Invoice data with tax details pushed successfully!"

def calculate_totals(materials):
    total_tax = round(sum(item["tax_amount"] for item in materials), 2)
    total_amount = round(sum(item["total_amount"] for item in materials), 2)
    return total_tax, total_amount


# Route to fetch invoice data and render invoices.html
@app.route('/invoice')
def get_invoices():
    invoice = collection.find_one()
    if invoice:
        materials = invoice.get("materials", [])
        total_tax, total_amount = calculate_totals(materials)
        return render_template('invoice.html', invoices=invoice, total_tax=total_tax, total_amount=total_amount)
    else:
        return "No invoice found"

if __name__ == "__main__":
    app.run(debug=True)
